package Utilidades;

public enum Direcci�n {
    norte,
    sur,
    este,
    oeste,
	noreste,
	noroeste,
	sureste,
	suroeste;
}
