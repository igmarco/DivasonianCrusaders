package Utilidades;

public enum Facci�n {
    Facci�n1,
    Facci�n2,
	Ambos; //Solo para indicar ganadores.
}
